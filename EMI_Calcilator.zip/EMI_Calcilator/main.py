import math
from datetime import datetime
import matplotlib.pyplot as plt
import sys

# Function to calculate EMI
def calculate_emi(principal, annual_rate, months):
    monthly_rate = (annual_rate / 100) / 12
    emi = principal * monthly_rate * math.pow(1 + monthly_rate, months) / (math.pow(1 + monthly_rate, months) - 1)
    return round(emi, 2)

# Save data to file with user details and payment information
def save_entry(entry):
    with open("emi_payment_history.txt", "a") as file:
        file.write(entry + "\n")

# Display pie chart
def show_pie_chart(principal, total_interest):
    labels = ['Principal Amount', 'Total Interest']
    values = [principal, total_interest]
    colors = ['#00FF00', '#FF0000']
    explode = (0.1, 0)

    plt.figure(figsize=(5, 5))
    plt.pie(values, labels=labels, colors=colors, autopct='%1.1f%%', startangle=135,
            explode=explode, shadow=True)
    plt.title("Sheetal's Graph: Principal vs Interest")
    plt.axis('equal')
    plt.show()

# Input section
print("\n :( Kripya Apna Suar jaisa Naam Bata do na")
user_name = input("Full Name: ")

try:
    income = float(input("Chal Be Bhondu bata mahine mai kitna Majduri Milta hai: "))
    if income <= 0:
        print("Abey Itna Kam bhi koi kamata hai kya bhondu zero. ? ")
        sys.exit()
except ValueError:
    print("Invalid Input. Enter a numeric value.")
    sys.exit()

# Loan application
while True:
    try:
        principal = float(input("\n Sun Be Tere ko kitne paise ki jarurat hai fate kapde waale ?: "))
        if principal <= 0:
            print("Abey Ghoncu tere se ummeed thee tu zero hi dalega, kutreya.")
            continue

        rate = float(input(" Chal be meethe rate bata (%): "))
        months = int(input("Enter the loan Duration in months: "))
        if months <= 0:
            print("Duration cannot be zero.")
            continue

        break
    except ValueError:
        print("Invalid Input. Please enter a numeric Value.")
        continue

emi = calculate_emi(principal, rate, months)
total_payment = round(emi * months, 2)
total_interest = round(total_payment - principal, 2)

# Summary
print("\nHere is your offer Summary:")
print(f"Applicant name: {user_name}")
print(f"Your Approved Loan Amount: {principal}")
print(f"Loan Duration: {months} months")
print(f"Rate: {rate}%")
print(f"EMI: {emi}")
print(f"Total Payable: {total_payment} (Interest: {total_interest})")

# Income check
if emi > income * 0.5:
    print("Kya re!! Muh utha aa gaya idhar bheekh maangne, chal jyaada paise kama kar aa.")

# Confirm loan
confirm = input("Do you accept this loan offer? (Yes or No): ").strip().lower()
if confirm != "yes":
    print("Loan not accepted. Goodbye.")
    sys.exit()

# Save user info
user_info = f"\nUser: {user_name} | Income: {income} | Loan: {principal} | Rate: {rate}% | Months: {months} | EMI: {emi}"
save_entry(user_info)
save_entry("Payment History:\n")

show_pie_chart(principal, total_interest)

# Payment loop
remaining = principal
month = 1
monthly_rate = (rate / 100) / 12

while remaining > 0 and month <= months:
    print(f"\nMonth {month} | Remaining Balance: {remaining:.2f}")
    interest = remaining * monthly_rate

    try:
        payment = float(input(f"Enter the payment (EMI is {emi}): "))
        if payment <= 0:
            print("Payment amount must be greater than Zero.")
            continue
        if payment > remaining + interest:
            print("Payment exceeds remaining + interest. Try again.")
            continue
        if payment < interest:
            print(f"Your payment {payment} is less than interest {interest}. Principal amount unchanged.")
            continue

        principal_paid = payment - interest
        remaining -= principal_paid

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = (f"{now} | Month {month} | Paid {payment:.2f} | Interest {interest:.2f} | "
                  f"Principal = {principal_paid:.2f} | Remaining = {remaining:.2f}")
        print("Payment Recorded:")
        print(record)
        save_entry(record)

        month += 1

        if remaining <= 0:
            print("\nBadhai ho Baawle, tune to poora karja chuka diya hai!")
            show_pie_chart(principal, total_interest)
            break

    except ValueError:
        print("Bansuri waale! Theek se number daal le.")

print("\nPayment data saved in 'emi_payment_history.txt'.")
