import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import styled from 'styled-components';
import { EMIService, EMICalculation } from '../services/emi';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 15px;
  box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(4px);
`;

const Form = styled.form`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
  margin-bottom: 2rem;
`;

const Input = styled.input`
  padding: 0.8rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
`;

const Select = styled.select`
  padding: 0.8rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
`;

const Button = styled.button`
  padding: 0.8rem 1.5rem;
  background: #4a90e2;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #357abd;
  }
`;

const Result = styled.div`
  margin-top: 2rem;
  padding: 1rem;
  background: #f8f9fa;
  border-radius: 8px;
`;

export default function EMICalculator() {
  const [calculation, setCalculation] = useState<EMICalculation>({
    principal: 0,
    interestRate: 0,
    tenure: 0,
    loanType: 'Home',
    currency: '₹',
    startDate: new Date().toISOString().split('T')[0]
  });

  const [schedule, setSchedule] = useState<any[]>([]);
  const [emi, setEmi] = useState<number>(0);

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    const calculatedEMI = EMIService.calculateEMI(
      calculation.principal,
      calculation.interestRate,
      calculation.tenure
    );
    setEmi(calculatedEMI);
    setSchedule(EMIService.generateAmortizationSchedule(calculation));
  };

  const handleExportExcel = () => {
    const excelData = EMIService.exportToExcel(schedule, calculation.currency);
    const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'emi_schedule.xlsx';
    a.click();
  };

  const handleExportPDF = () => {
    const pdfData = EMIService.generatePDF(calculation, schedule);
    const blob = new Blob([pdfData], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'emi_summary.pdf';
    a.click();
  };

  const chartData = {
    labels: schedule.map(item => `Month ${item.month}`),
    datasets: [
      {
        label: 'Principal Paid',
        data: schedule.map(item => item.principalPaid),
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      },
      {
        label: 'Interest Paid',
        data: schedule.map(item => item.interestPaid),
        borderColor: 'rgb(255, 99, 132)',
        tension: 0.1
      }
    ]
  };

  return (
    <Container>
      <h1>EMI Calculator</h1>
      <Form onSubmit={handleCalculate}>
        <div>
          <label>Principal Amount</label>
          <Input
            type="number"
            value={calculation.principal}
            onChange={e => setCalculation({ ...calculation, principal: Number(e.target.value) })}
            required
          />
        </div>
        <div>
          <label>Interest Rate (%)</label>
          <Input
            type="number"
            value={calculation.interestRate}
            onChange={e => setCalculation({ ...calculation, interestRate: Number(e.target.value) })}
            required
          />
        </div>
        <div>
          <label>Tenure (months)</label>
          <Input
            type="number"
            value={calculation.tenure}
            onChange={e => setCalculation({ ...calculation, tenure: Number(e.target.value) })}
            required
          />
        </div>
        <div>
          <label>Loan Type</label>
          <Select
            value={calculation.loanType}
            onChange={e => setCalculation({ ...calculation, loanType: e.target.value })}
          >
            <option value="Home">Home Loan</option>
            <option value="Personal">Personal Loan</option>
            <option value="Car">Car Loan</option>
            <option value="Education">Education Loan</option>
          </Select>
        </div>
        <div>
          <label>Currency</label>
          <Select
            value={calculation.currency}
            onChange={e => setCalculation({ ...calculation, currency: e.target.value })}
          >
            <option value="₹">Indian Rupee (₹)</option>
            <option value="$">US Dollar ($)</option>
            <option value="€">Euro (€)</option>
            <option value="¥">Japanese Yen (¥)</option>
          </Select>
        </div>
        <div>
          <label>Start Date</label>
          <Input
            type="date"
            value={calculation.startDate}
            onChange={e => setCalculation({ ...calculation, startDate: e.target.value })}
            required
          />
        </div>
        <Button type="submit">Calculate EMI</Button>
      </Form>

      {emi > 0 && (
        <Result>
          <h2>Monthly EMI: {calculation.currency} {emi.toFixed(2)}</h2>
          <div style={{ height: '400px', marginTop: '2rem' }}>
            <Line data={chartData} options={{ responsive: true }} />
          </div>
          <div style={{ marginTop: '2rem' }}>
            <Button onClick={handleExportExcel}>Export to Excel</Button>
            <Button onClick={handleExportPDF} style={{ marginLeft: '1rem' }}>Export to PDF</Button>
          </div>
        </Result>
      )}
    </Container>
  );
} 