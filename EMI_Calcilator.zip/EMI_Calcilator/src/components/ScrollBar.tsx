import React, { useEffect, useState } from 'react';
import styled, { keyframes } from 'styled-components';

const float = keyframes`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
`;

const pulse = keyframes`
  0% { transform: scale(1); }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); }
`;

const Container = styled.div`
  position: fixed;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
  z-index: 1000;
`;

const ScrollTrack = styled.div`
  width: 4px;
  height: 200px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 2px;
  position: relative;
  overflow: hidden;
`;

const ScrollThumb = styled.div<{ progress: number }>`
  width: 100%;
  height: ${props => props.progress}%;
  background: linear-gradient(45deg, #ff6b6b, #ffa0e0);
  border-radius: 2px;
  position: absolute;
  top: 0;
  left: 0;
  transition: height 0.1s ease;
`;

const LoveMessage = styled.div`
  writing-mode: vertical-rl;
  text-orientation: mixed;
  color: #ff6b6b;
  font-size: 14px;
  font-weight: 500;
  letter-spacing: 2px;
  animation: ${float} 3s ease-in-out infinite;
  display: flex;
  align-items: center;
  gap: 8px;

  &::before {
    content: '❤';
    font-size: 16px;
    animation: ${pulse} 1.5s ease-in-out infinite;
  }
`;

export default function ScrollBar() {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      const scrollTop = window.scrollY;
      const progress = (scrollTop / (documentHeight - windowHeight)) * 100;
      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Container>
      <ScrollTrack>
        <ScrollThumb progress={scrollProgress} />
      </ScrollTrack>
      <LoveMessage>Made with love from Sheetal</LoveMessage>
    </Container>
  );
} 