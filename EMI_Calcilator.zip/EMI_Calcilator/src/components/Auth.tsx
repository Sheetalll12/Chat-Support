import React, { useState } from 'react';
import styled from 'styled-components';
import { AuthService } from '../services/auth';

const Container = styled.div`
  max-width: 400px;
  margin: 2rem auto;
  padding: 2rem;
  background: rgba(255, 255, 255, 0.9);
  border-radius: 15px;
  box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
  backdrop-filter: blur(4px);
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const Input = styled.input`
  padding: 0.8rem;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
`;

const Button = styled.button`
  padding: 0.8rem;
  background: #4a90e2;
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #357abd;
  }
`;

const ToggleButton = styled.button`
  background: none;
  border: none;
  color: #4a90e2;
  cursor: pointer;
  margin-top: 1rem;
  font-size: 0.9rem;

  &:hover {
    text-decoration: underline;
  }
`;

export default function Auth({ onAuthSuccess }: { onAuthSuccess: (user: any) => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    phone: ''
  });
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [userId, setUserId] = useState<number | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isLogin) {
      const result = await AuthService.login(formData.email, formData.password);
      if (result.success) {
        setShowOtpInput(true);
        setUserId(result.user.id);
      } else {
        alert(result.error);
      }
    } else {
      const result = await AuthService.register(
        formData.username,
        formData.email,
        formData.password,
        formData.phone
      );
      if (result.success) {
        setShowOtpInput(true);
        setUserId(result.userId);
      } else {
        alert(result.error);
      }
    }
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId) return;

    const isValid = await AuthService.verifyOTP(userId, otp);
    if (isValid) {
      onAuthSuccess({ id: userId, ...formData });
    } else {
      alert('Invalid OTP');
    }
  };

  return (
    <Container>
      <h2>{isLogin ? 'Login' : 'Register'}</h2>
      {!showOtpInput ? (
        <Form onSubmit={handleSubmit}>
          {!isLogin && (
            <Input
              type="text"
              placeholder="Username"
              value={formData.username}
              onChange={e => setFormData({ ...formData, username: e.target.value })}
              required
            />
          )}
          <Input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={e => setFormData({ ...formData, email: e.target.value })}
            required
          />
          <Input
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={e => setFormData({ ...formData, password: e.target.value })}
            required
          />
          {!isLogin && (
            <Input
              type="tel"
              placeholder="Phone Number"
              value={formData.phone}
              onChange={e => setFormData({ ...formData, phone: e.target.value })}
              required
            />
          )}
          <Button type="submit">{isLogin ? 'Login' : 'Register'}</Button>
          <ToggleButton type="button" onClick={() => setIsLogin(!isLogin)}>
            {isLogin ? 'Need an account? Register' : 'Already have an account? Login'}
          </ToggleButton>
        </Form>
      ) : (
        <Form onSubmit={handleOtpSubmit}>
          <Input
            type="text"
            placeholder="Enter OTP"
            value={otp}
            onChange={e => setOtp(e.target.value)}
            required
          />
          <Button type="submit">Verify OTP</Button>
        </Form>
      )}
    </Container>
  );
} 