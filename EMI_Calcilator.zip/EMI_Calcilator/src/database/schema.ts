import Database from 'better-sqlite3';
import path from 'path';

const db = new Database(path.join(__dirname, 'emi_calculator.db'));

// Create users table
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

// Create otp table
db.exec(`
  CREATE TABLE IF NOT EXISTS otp (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    otp_code TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )
`);

// Create emi_calculations table
db.exec(`
  CREATE TABLE IF NOT EXISTS emi_calculations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    principal REAL NOT NULL,
    interest_rate REAL NOT NULL,
    tenure INTEGER NOT NULL,
    emi_amount REAL NOT NULL,
    loan_type TEXT NOT NULL,
    currency TEXT NOT NULL,
    start_date DATE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  )
`);

export default db; 