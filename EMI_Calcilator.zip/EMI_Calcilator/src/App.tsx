import React, { useState } from 'react';
import styled from 'styled-components';
import Background3D from './components/Background3D';
import Auth from './components/Auth';
import EMICalculator from './components/EMICalculator';
import ScrollBar from './components/ScrollBar';

const AppContainer = styled.div`
  min-height: 100vh;
  padding: 2rem;
  color: #333;
`;

const Header = styled.header`
  text-align: center;
  margin-bottom: 2rem;
  color: #4a90e2;
`;

export default function App() {
  const [user, setUser] = useState<any>(null);

  return (
    <AppContainer>
      <Background3D />
      <ScrollBar />
      <Header>
        <h1>EMI Calculator</h1>
      </Header>
      {!user ? (
        <Auth onAuthSuccess={setUser} />
      ) : (
        <EMICalculator />
      )}
    </AppContainer>
  );
} 