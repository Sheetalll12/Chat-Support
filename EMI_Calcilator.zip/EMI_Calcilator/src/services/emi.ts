import db from '../database/schema';
import * as XLSX from 'xlsx';
import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';

pdfMake.vfs = pdfFonts.pdfMake.vfs;

export interface EMICalculation {
  principal: number;
  interestRate: number;
  tenure: number;
  loanType: string;
  currency: string;
  startDate: string;
}

export class EMIService {
  static calculateEMI(principal: number, interestRate: number, tenure: number): number {
    const monthlyRate = interestRate / 12 / 100;
    const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, tenure) / (Math.pow(1 + monthlyRate, tenure) - 1);
    return Number(emi.toFixed(2));
  }

  static generateAmortizationSchedule(calculation: EMICalculation) {
    const { principal, interestRate, tenure, startDate } = calculation;
    const monthlyRate = interestRate / 12 / 100;
    const emi = this.calculateEMI(principal, interestRate, tenure);
    let balance = principal;
    const schedule = [];

    for (let i = 1; i <= tenure; i++) {
      const interest = balance * monthlyRate;
      const principalPaid = emi - interest;
      balance -= principalPaid;

      schedule.push({
        month: i,
        date: new Date(startDate).setMonth(new Date(startDate).getMonth() + i - 1),
        emi: emi,
        principalPaid: Number(principalPaid.toFixed(2)),
        interestPaid: Number(interest.toFixed(2)),
        remainingBalance: Number(balance.toFixed(2))
      });
    }

    return schedule;
  }

  static async saveCalculation(userId: number, calculation: EMICalculation) {
    const emi = this.calculateEMI(calculation.principal, calculation.interestRate, calculation.tenure);
    
    return db.prepare(`
      INSERT INTO emi_calculations (
        user_id, principal, interest_rate, tenure, emi_amount,
        loan_type, currency, start_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      userId,
      calculation.principal,
      calculation.interestRate,
      calculation.tenure,
      emi,
      calculation.loanType,
      calculation.currency,
      calculation.startDate
    );
  }

  static exportToExcel(schedule: any[], currency: string) {
    const worksheet = XLSX.utils.json_to_sheet(schedule.map(item => ({
      Month: item.month,
      Date: new Date(item.date).toLocaleDateString(),
      EMI: `${currency} ${item.emi}`,
      'Principal Paid': `${currency} ${item.principalPaid}`,
      'Interest Paid': `${currency} ${item.interestPaid}`,
      'Remaining Balance': `${currency} ${item.remainingBalance}`
    })));

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'EMI Schedule');
    return XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });
  }

  static generatePDF(calculation: EMICalculation, schedule: any[]) {
    const docDefinition = {
      content: [
        { text: 'EMI Calculation Summary', style: 'header' },
        { text: `Loan Type: ${calculation.loanType}` },
        { text: `Principal: ${calculation.currency} ${calculation.principal}` },
        { text: `Interest Rate: ${calculation.interestRate}%` },
        { text: `Tenure: ${calculation.tenure} months` },
        { text: `Monthly EMI: ${calculation.currency} ${this.calculateEMI(
          calculation.principal,
          calculation.interestRate,
          calculation.tenure
        )}` },
        {
          text: 'Amortization Schedule',
          style: 'subheader'
        },
        {
          table: {
            headerRows: 1,
            widths: ['*', '*', '*', '*', '*'],
            body: [
              ['Month', 'EMI', 'Principal', 'Interest', 'Balance'],
              ...schedule.map(item => [
                item.month,
                `${calculation.currency} ${item.emi}`,
                `${calculation.currency} ${item.principalPaid}`,
                `${calculation.currency} ${item.interestPaid}`,
                `${calculation.currency} ${item.remainingBalance}`
              ])
            ]
          }
        }
      ],
      styles: {
        header: {
          fontSize: 18,
          bold: true,
          margin: [0, 0, 0, 10]
        },
        subheader: {
          fontSize: 14,
          bold: true,
          margin: [0, 10, 0, 5]
        }
      }
    };

    return pdfMake.createPdf(docDefinition).getBuffer();
  }

  static calculateLatePaymentPenalty(emi: number, daysLate: number): number {
    const penaltyRate = 0.02; // 2% per day
    return Number((emi * penaltyRate * daysLate).toFixed(2));
  }

  static calculatePrepayment(principal: number, prepaymentAmount: number, interestRate: number, remainingTenure: number) {
    const newPrincipal = principal - prepaymentAmount;
    const newEMI = this.calculateEMI(newPrincipal, interestRate, remainingTenure);
    return {
      newEMI,
      reducedAmount: Number((this.calculateEMI(principal, interestRate, remainingTenure) - newEMI).toFixed(2))
    };
  }
} 