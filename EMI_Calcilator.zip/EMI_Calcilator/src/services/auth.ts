import db from '../database/schema';
import crypto from 'crypto';

export class AuthService {
  private static generateOTP(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  static async register(username: string, email: string, password: string, phone: string) {
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    
    try {
      const result = db.prepare(`
        INSERT INTO users (username, email, password, phone)
        VALUES (?, ?, ?, ?)
      `).run(username, email, hashedPassword, phone);

      const otp = this.generateOTP();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      db.prepare(`
        INSERT INTO otp (user_id, otp_code, expires_at)
        VALUES (?, ?, ?)
      `).run(result.lastInsertRowid, otp, expiresAt.toISOString());

      // In a real application, you would send this OTP via SMS
      console.log(`OTP for ${phone}: ${otp}`);
      
      return { success: true, userId: result.lastInsertRowid };
    } catch (error) {
      return { success: false, error: 'Registration failed' };
    }
  }

  static async verifyOTP(userId: number, otp: string) {
    const result = db.prepare(`
      SELECT * FROM otp 
      WHERE user_id = ? AND otp_code = ? AND expires_at > datetime('now')
      ORDER BY created_at DESC LIMIT 1
    `).get(userId, otp);

    return !!result;
  }

  static async login(email: string, password: string) {
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    
    const user = db.prepare(`
      SELECT id, username, email, phone FROM users
      WHERE email = ? AND password = ?
    `).get(email, hashedPassword);

    if (user) {
      const otp = this.generateOTP();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

      db.prepare(`
        INSERT INTO otp (user_id, otp_code, expires_at)
        VALUES (?, ?, ?)
      `).run(user.id, otp, expiresAt.toISOString());

      // In a real application, you would send this OTP via SMS
      console.log(`OTP for ${user.phone}: ${otp}`);
      
      return { success: true, user };
    }

    return { success: false, error: 'Invalid credentials' };
  }
} 