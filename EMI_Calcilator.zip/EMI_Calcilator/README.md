# EMI Calculator

A modern, interactive EMI calculator application built with React, TypeScript, and Three.js. Features include user authentication, OTP verification, and comprehensive EMI calculation tools.

## Features

- 📈 Calculate EMI based on Principal, Annual Interest Rate, and Tenure
- 📊 EMI Amortization Schedule (month-by-month breakdown)
- 🧾 Interest vs Principal Split for each month
- 💰 Remaining Balance Calculation after every EMI
- 📤 Export EMI Schedule as CSV / Excel
- 📄 Generate PDF Loan Summary
- 📆 Custom Payment Start Date selection
- 🌐 Currency Selection (₹, $, €, ¥ etc.)
- 🕓 Late Payment Penalty Calculator
- 🚀 Prepayment Option (reduce EMI or tenure)
- 📉 Interactive Graphs
- 📱 User Authentication with OTP
- 🎨 Modern 3D UI with animated background

## Prerequisites

- Node.js (v14 or higher)
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd emi-calculator
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:3000`

## Usage

1. Register a new account or login with existing credentials
2. Verify your account using the OTP sent to your phone
3. Use the EMI calculator to:
   - Input loan details (principal, interest rate, tenure)
   - Select loan type and currency
   - View detailed amortization schedule
   - Export results to Excel or PDF
   - Analyze payment breakdown with interactive graphs

## Technologies Used

- React
- TypeScript
- Three.js
- Chart.js
- SQLite
- Styled Components
- Vite

## License

MIT 